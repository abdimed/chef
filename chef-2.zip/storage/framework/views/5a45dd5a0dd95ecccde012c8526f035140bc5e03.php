<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <div class="p-6 bg-sky-500 flex h-screen lg:h-fit justify-center items-center flex-col ">
        <div class="m-auto">
        <p class=" text-white text-center text-lg font-semibold " > شكرا على المشاركة يرجى منكم الذهاب إلى صفحت الفايسبوك  </p>
        <a href="https://www.facebook.com/elhayatschool.dz" class="mt-10 flex justify-center" >
            <img src="<?php echo e(asset('assets/fb.svg')); ?>" class="animate-bounce" />
         </a>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\moog\Desktop\Elhayat school\chef-2\resources\views/thanks.blade.php ENDPATH**/ ?>