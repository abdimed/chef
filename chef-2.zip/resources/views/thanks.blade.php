<x-app-layout>


    <div class="p-6 bg-sky-600 flex h-screen lg:h-fit justify-center items-center flex-col ">
        <div class="m-auto">
        <p class=" text-white text-center text-lg font-semibold " > شكرا على المشاركة يرجى منكم الذهاب إلى صفحت الفايسبوك  </p>
        <a href="https://www.facebook.com/elhayatschool.dz" class="mt-10 flex justify-center" >
            <img src="{{asset('assets/fb.svg')}}" class="animate-bounce" />
         </a>
        </div>
    </div>

</x-app-layout>
